#!/bin/bash
/usr/local/tomcat/bin/startup.sh
service mysql restart
/usr/bin/mysqld_safe
find /var/lib/mysql/mysql -exec touch -c -a {} +
tail -f /dev/null
