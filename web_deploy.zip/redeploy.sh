#!/bin/bash
cd /home/src
build_output=$(mvn clean package -o -DskipTest)

if echo "$build_output" | grep -q "BUILD SUCCESS"; then
    echo "[+]build success"
    mv /home/src/target/drug-0.0.1-SNAPSHOT.war /usr/local/tomcat/webapps/ROOT.war
    echo "[+]正在重启tomcat"
    /usr/local/tomcat/bin/shutdown.sh
    /usr/local/tomcat/bin/startup.sh
    echo "[+]重新部署完成"
else
    echo "build faild:"
    echo "$build_output"
fi
